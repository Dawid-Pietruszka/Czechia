from flask import Flask, url_for
from datetime import datetime
from flask import render_template, request
import re
import random, copy
import pymongo
from pymongo import MongoClient
from itertools import chain

app = Flask(__name__)

questionCount = 0
provinceCount = 0
totalQ = 0
provinces = []
totalP = 0
original_questions = {}
def getQuestion():
    cluster = MongoClient("mongodb+srv://Admin:1234@cluster0.tfwfz.mongodb.net/Courseworkdata?retryWrites=true&w=majority")
    db = cluster["Courseworkdata"]
    collection = db["Questions"]
    collection1 = db["CzechiaProvince"]

    total = collection.find({})
    total1 = collection1.find({})
    global totalQ 
    global totalP
    global original_questions
    totalQ = total.count()
    totalP = total1.count()
    question = collection.find({"_id":questionCount})

    for result in question:
        original_questions = {result["Question"] :[result['Answer1'], result['Answer2'], result['Answer3'], result['Answer4']]}

    originalList = list(original_questions.values())

    splitList = list(chain.from_iterable(originalList))

    firstKey = list(original_questions.keys())

    Answer = random.sample(splitList, len(splitList))

    finalDict = { firstKey[0]:[Answer[0], Answer[1], Answer[2], Answer[3]]}

    questions = copy.deepcopy(finalDict)

    return (questions)

@app.route("/")
def home():

    global questionCount, provinceCount, totalQ, provinces, totalP
    questionCount = 0
    provinceCount = 0
    totalQ = 0
    provinces.clear()
    totalP = 0
    
    return render_template("index.html")

@app.route("/about/")
def about():

    global questionCount, provinceCount, totalQ, provinces, totalP
    questionCount = 0
    provinceCount = 0
    totalQ = 0
    provinces.clear()
    totalP = 0

    return render_template("about.html")

@app.route("/game/", methods=['GET', 'POST'])
def game():

    global questionCount
    questionCount = 0

    return render_template("game.html", q = getQuestion())

@app.route("/gamenext/", methods=['POST'])
def gamenext():

    global questionCount, provinces, totalP
    questionCount = questionCount + 1
    
    if questionCount == totalQ or provinceCount == totalP:

        return render_template("game.html", p = provinces, totalP = totalP)
    else:

        return render_template("game.html", q = getQuestion(),  p = provinces)

@app.route('/gamechck/', methods=['POST'])
def gamechck():
 global provinces, provinceCount, original_questions
 questions = getQuestion()
 correct = 0
 for i in questions.keys():
  answered = request.form[i]
  if original_questions[i][0] == answered:
   correct = correct+1
   provinceCount = provinceCount + 1
   provinces.append(request.form["Province"])

 return render_template("gamechck.html", a = correct, q = questions, c = questions[i][0],  p = provinces)

@app.route('/quiz', methods=['POST'])
def quiz_answers():
 correct = 0
 for i in questions.keys():
  answered = request.form[i]
  if original_questions[i][0] == answered:
   correct = correct+1

 return '<h1>Correct Answers: <u>'+str(correct)+'</u></h1>'